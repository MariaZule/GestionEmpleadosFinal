import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class VentanaEmpleados extends javax.swing.JFrame {
    DefaultTableModel modelo;
    TableRowSorter<DefaultTableModel> sorter;
    public VentanaEmpleados() {
        initComponents();
        
        modelo = (DefaultTableModel) jTable1.getModel();

    // Agrega los empleados
        modelo.addRow(new Object[]{"Maria Isabel", "Marketing", "Permanente", "Ventas"});
        modelo.addRow(new Object[]{"Hernan Javier", "Ventas", "Permanente", "Ventas"});
        modelo.addRow(new Object[]{"Sandra Zapata", "Marketing", "Permanente", "Soporte"});
        modelo.addRow(new Object[]{"Andres Felipe", "Ventas", "Temporal", "Ventas"});
        modelo.addRow(new Object[]{"Sara Velasquez", "Marketing", "Temporal", "Marketing"});
        modelo.addRow(new Object[]{"Felipe Castrillón", "Asesor ventas", "Temporal", "Ventas"});
        modelo.addRow(new Object[]{"Kelly Múnera", "Marketing", "Permanente", "Marketing"});
        modelo.addRow(new Object[]{"Luis Andrade", "Soporte", "Temporal", "Servicio al cliente"});
        modelo.addRow(new Object[]{"Valentina Vélez", "Soporte", "Permanente", "Servicio al cliente"});
        modelo.addRow(new Object[]{"Leydi Zuleta", "Manager", "Permanente", "Customer Success"});
        modelo.addRow(new Object[]{"Diego Mena", "Asesor", "Temporal", "Ventas"});

    // Configura el sorter para filtrar
        sorter = new TableRowSorter<>(modelo);
        jTable1.setRowSorter(sorter);

    // Acción del botón buscar
    jButton4.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
        String texto = jTextField1.getText();
        if (texto.trim().length() == 0) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto));
        }
    }
});
    jTable1.getSelectionModel().addListSelectionListener(e -> {
    int fila = jTable1.getSelectedRow();
    if (fila != -1) {
        // Convertimos índice visual a modelo (por el sorter)
        int filaModelo = jTable1.convertRowIndexToModel(fila);

        jTextField1.setText(modelo.getValueAt(filaModelo, 0).toString()); // Nombre
        jTextField2.setText(modelo.getValueAt(filaModelo, 1).toString()); // Cargo
        jTextField3.setText(modelo.getValueAt(filaModelo, 2).toString()); // Tipo
        jTextField4.setText(modelo.getValueAt(filaModelo, 3).toString()); // Departamento
    }
});
    // Acción del botón Actualizar
    jButton2.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(java.awt.event.ActionEvent evt) {
        int fila = jTable1.getSelectedRow();
        if (fila != -1) {
            int filaModelo = jTable1.convertRowIndexToModel(fila);

            // Toma los nuevos valores desde los campos
            String nombre = jTextField1.getText();
            String cargo = jTextField2.getText();
            String tipo = jTextField3.getText();
            String departamento = jTextField4.getText();

            // Actualiza los valores en el modelo
            modelo.setValueAt(nombre, filaModelo, 0);        // Columna 0: Nombre
            modelo.setValueAt(cargo, filaModelo, 1);         // Columna 1: Cargo
            modelo.setValueAt(tipo, filaModelo, 2);          // Columna 2: Tipo
            modelo.setValueAt(departamento, filaModelo, 3);  // Columna 3: Departamento

            JOptionPane.showMessageDialog(null, "Empleado actualizado correctamente.");
        } else {
            JOptionPane.showMessageDialog(null, "Selecciona un empleado para actualizar.");
        }
    }
});
    jButton3.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(java.awt.event.ActionEvent evt) {
        int fila = jTable1.getSelectedRow();
        if (fila != -1) {
            int filaModelo = jTable1.convertRowIndexToModel(fila);
            
            int confirmacion = JOptionPane.showConfirmDialog(null, 
                "¿Estás seguro de que deseas eliminar este empleado?", 
                "Confirmar eliminación", 
                JOptionPane.YES_NO_OPTION);
            
            if (confirmacion == JOptionPane.YES_OPTION) {
                modelo.removeRow(filaModelo);
                JOptionPane.showMessageDialog(null, "Empleado eliminado correctamente.");
                
                // Opcional: limpiar los campos
                jTextField1.setText("");
                jTextField2.setText("");
                jTextField3.setText("");
                jTextField4.setText("");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Selecciona un empleado para eliminar.");
        }
    }
});
    jButton5.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        dispose(); // Cierra esta ventana
        VentanaPrincipal ventanaPrincipal = new VentanaPrincipal();
        ventanaPrincipal.setVisible(true);
    }
});

    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Nombre:");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("Cargo:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Tipo:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Departamento:");

        jTextField1.setBackground(new java.awt.Color(204, 204, 255));
        jTextField1.setText("Nombre completo");

        jTextField2.setBackground(new java.awt.Color(204, 204, 255));
        jTextField2.setText("Escribe el cargo");

        jTextField3.setBackground(new java.awt.Color(204, 204, 255));
        jTextField3.setText("Temporal o permanente");

        jTextField4.setBackground(new java.awt.Color(204, 204, 255));
        jTextField4.setText("Escribe el departamento");

        jButton1.setBackground(new java.awt.Color(153, 204, 255));
        jButton1.setText("Guardar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(153, 204, 255));
        jButton2.setText("Actualizar");

        jButton3.setBackground(new java.awt.Color(153, 204, 255));
        jButton3.setText("Eliminar");

        jButton4.setBackground(new java.awt.Color(153, 204, 255));
        jButton4.setText("Buscar");

        jTable1.setBackground(new java.awt.Color(204, 255, 255));
        jTable1.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Cargo", "Tipo", "Departamento"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jLabel5.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(102, 102, 255));
        jLabel5.setText("Gestión de empleados CompuWork");
        jLabel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButton5.setBackground(new java.awt.Color(255, 153, 153));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton5.setText("<- Atrás");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addGap(176, 176, 176)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton4)
                                .addGap(34, 34, 34)
                                .addComponent(jButton1)
                                .addGap(35, 35, 35)
                                .addComponent(jButton2)
                                .addGap(35, 35, 35)
                                .addComponent(jButton3))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 519, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton5)
                        .addGap(33, 33, 33)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jTextField1, jTextField2, jTextField3, jTextField4});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel5)
                        .addGap(30, 30, 30))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton5)
                        .addGap(18, 18, 18)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jButton3)
                    .addComponent(jButton2)
                    .addComponent(jButton1)
                    .addComponent(jButton4))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    String nombre = jTextField1.getText();
    String cargo = jTextField2.getText();
    String tipo = jTextField3.getText().toLowerCase(); // "temporal" o "permanente"
    String departamento = jTextField4.getText();

    // Datos adicionales simulados
    String apellido = "ApellidoX";
    String id = "EMP" + System.currentTimeMillis(); // ID único por tiempo
    Date fechaIngreso = new Date(); // Fecha actual
    ReporteDesempeño desempeño = new ReporteDesempeño();

    Empleado empleado = null;

    if (tipo.equals("temporal")) {
        double tarifaPorHora = 30000; 
        int horasTrabajadas = 120;    
        Date fechaFinContrato = new Date(); 

        empleado = new EmpleadoTemporal(nombre, apellido, id, departamento, tipo, tarifaPorHora, horasTrabajadas, fechaIngreso, fechaFinContrato, desempeño);

    } else if (tipo.equals("permanente")) {
        double salarioMensual = 2500000; 

        empleado = new EmpleadoPermanente(nombre, apellido, id, departamento, tipo, salarioMensual, fechaIngreso, desempeño);
    } else {
        JOptionPane.showMessageDialog(this, "Tipo de empleado no válido. Usa 'temporal' o 'permanente'.");
        return;
    }

    // Agregar a la tabla
    DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();
    modelo.addRow(new Object[]{nombre, cargo, tipo, departamento});

    // Limpiar campos
    jTextField1.setText("");
    jTextField2.setText("");
    jTextField3.setText("");
    jTextField4.setText("");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaEmpleados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    // End of variables declaration//GEN-END:variables
}
