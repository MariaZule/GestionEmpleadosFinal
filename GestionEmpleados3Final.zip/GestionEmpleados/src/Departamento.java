import java.util.ArrayList;
import java.util.List;

public class Departamento {
    private String nombreDepartamento;
    private String descripcion;
    private String jefe;
    private List<Empleado> empleados; // ✅ Solo una lista de empleados

    public Departamento(String nombreDepartamento, String descripcion, String jefe) {
        this.nombreDepartamento = nombreDepartamento;
        this.descripcion = descripcion;
        this.jefe = jefe;
        this.empleados = new ArrayList<>();
    }

    public String getNombreDepartamento() {
        return nombreDepartamento;
    }

    public void setNombreDepartamento(String nombreDepartamento) {
        this.nombreDepartamento = nombreDepartamento;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getJefe() {
        return jefe;
    }

    public void setJefe(String jefe) {
        this.jefe = jefe;
    }

    public List<Empleado> getEmpleados() {
        return empleados;
    }

    public void agregarEmpleado(Empleado empleado) {
        empleados.add(empleado);
    }

    public void eliminarEmpleado(String id) throws Exception {
        for (Empleado e : empleados) {
            if (e.getId().equals(id)) { // 👈 Usa equals para comparar Strings
                empleados.remove(e);
                return;
            }
        }
        throw new Exception("Empleado no encontrado");
    }

    @Override
    public String toString() {
        StringBuilder empleadosInfo = new StringBuilder();
        for (Empleado e : empleados) {
            empleadosInfo.append("\n - ").append(e.getNombre()).append(" ").append(e.getApellido());
        }

        return "Departamento: " + nombreDepartamento +
                "\nDescripción: " + descripcion +
                "\nJefe: " + jefe +
                "\nEmpleados:" + empleadosInfo;
    }
}
