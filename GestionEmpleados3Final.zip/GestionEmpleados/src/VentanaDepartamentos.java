
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

public class VentanaDepartamentos extends javax.swing.JFrame {

    DefaultTableModel modeloDepartamentos;
    
    private void cargarDepartamentos() {
    modeloDepartamentos.setRowCount(0); // Limpia la tabla

    for (Departamento depto : Main.listaDepartamentos) {
        String nombre = depto.getNombreDepartamento();
        String descripcion = depto.getDescripcion();
        String jefe = depto.getJefe();
        int cantidadEmpleados = depto.getEmpleados().size();

        modeloDepartamentos.addRow(new Object[]{nombre, descripcion, jefe, cantidadEmpleados});
    }
}
    public VentanaDepartamentos() {
        initComponents();
        modeloDepartamentos = new DefaultTableModel(
        new Object[][]{},
        new String[]{"Nombre", "Descripción", "Jefe", "Cantidad Empleados"}
    );
        jButton1.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent evt) {
        String nombre = jTextField1.getText().trim();
        String descripcion = jTextField2.getText().trim();
        String jefe = jTextField3.getText().trim();

        if (!nombre.isEmpty() && !descripcion.isEmpty() && !jefe.isEmpty()) {
            // Crear el nuevo departamento
            Departamento nuevoDepto = new Departamento(nombre, descripcion, jefe);

            // Agregar a la lista principal
            Main.listaDepartamentos.add(nuevoDepto);

            // Recargar la tabla
            cargarDepartamentos();

            // Limpiar los campos
            jTextField1.setText("");
            jTextField2.setText("");
            jTextField3.setText("");
        } else {
            javax.swing.JOptionPane.showMessageDialog(
                null,
                "Por favor complete todos los campos.",
                "Campos vacíos",
                javax.swing.JOptionPane.WARNING_MESSAGE
            );
        }
    }
});
        jButton2.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent evt) {
        int filaSeleccionada = jTable1.getSelectedRow();

        if (filaSeleccionada != -1) {
            // Confirmar eliminación
            int confirmacion = javax.swing.JOptionPane.showConfirmDialog(
                null,
                "¿Deseas eliminar este departamento?",
                "Confirmar eliminación",
                javax.swing.JOptionPane.YES_NO_OPTION
            );

            if (confirmacion == javax.swing.JOptionPane.YES_OPTION) {
                // Eliminar del ArrayList y recargar tabla
                Main.listaDepartamentos.remove(filaSeleccionada);
                cargarDepartamentos();
            }
        } else {
            javax.swing.JOptionPane.showMessageDialog(
                null,
                "Por favor selecciona un departamento para eliminar.",
                "Ninguna fila seleccionada",
                javax.swing.JOptionPane.WARNING_MESSAGE
            );
        }
    }
});
        jButton3.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(ActionEvent evt) {
        int filaSeleccionada = jTable1.getSelectedRow();

        if (filaSeleccionada != -1) {
            Departamento deptoSeleccionado = Main.listaDepartamentos.get(filaSeleccionada);

            javax.swing.JOptionPane.showMessageDialog(
                null,
                "Empleados del departamento " + deptoSeleccionado.getNombreDepartamento() +
                ":\n" + deptoSeleccionado.getEmpleados().toString(),
                "Empleados",
                javax.swing.JOptionPane.INFORMATION_MESSAGE
            );
        } else {
            javax.swing.JOptionPane.showMessageDialog(
                null,
                "Por favor selecciona un departamento para ver sus empleados.",
                "Ninguna fila seleccionada",
                javax.swing.JOptionPane.WARNING_MESSAGE
            );
        }
    }
});
        
        jButton4.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(ActionEvent evt) {
        dispose(); // Cierra esta ventana
        new VentanaPrincipal().setVisible(true); // Abre la ventana principal
    }
});

    // Asignar el modelo a la tabla
    jTable1.setModel(modeloDepartamentos);

    // Cargar los datos
    cargarDepartamentos();
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 255));
        jLabel1.setText("Gestión de Departamentos CompuWork");
        jLabel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("Nombre:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Descripción:");

        jTextField1.setBackground(new java.awt.Color(204, 204, 255));
        jTextField1.setText("Nombre Departamento");
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jTextField2.setBackground(new java.awt.Color(204, 204, 255));
        jTextField2.setText("Descripción del Departamento");
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Jefe:");

        jTextField3.setBackground(new java.awt.Color(204, 204, 255));
        jTextField3.setText("Nombre del jefe");
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(153, 204, 255));
        jButton1.setText("Agregar");

        jButton2.setBackground(new java.awt.Color(153, 204, 255));
        jButton2.setText("Eliminar");

        jButton3.setBackground(new java.awt.Color(153, 204, 255));
        jButton3.setText("Ver Empleados");

        jTable1.setBackground(new java.awt.Color(204, 255, 255));
        jTable1.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Departamento", "Descripción", "Jefe", "Cantidad Empleados"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton4.setBackground(new java.awt.Color(255, 153, 153));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton4.setText("<- Atrás");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 482, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1))
                        .addGap(71, 71, 71)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jTextField1)
                                .addComponent(jTextField2, javax.swing.GroupLayout.DEFAULT_SIZE, 195, Short.MAX_VALUE)
                                .addComponent(jTextField3))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jButton2)
                                .addGap(69, 69, 69)
                                .addComponent(jButton3))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton4)
                        .addGap(15, 15, 15)
                        .addComponent(jLabel1)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jLabel1)
                        .addGap(31, 31, 31))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGap(30, 30, 30)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    // End of variables declaration//GEN-END:variables
}
